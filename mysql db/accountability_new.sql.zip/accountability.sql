-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 01, 2012 at 07:38 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `accountability`
--

-- --------------------------------------------------------

--
-- Table structure for table `Entity`
--

CREATE TABLE `Entity` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `name` varchar(30) DEFAULT 'anonymous',
  `score` bigint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Entity`
--

INSERT INTO `Entity` VALUES(1, 'anonymous1', 1);
INSERT INTO `Entity` VALUES(2, 'anonymous2', 1);
INSERT INTO `Entity` VALUES(3, 'anonymous3', 1);
INSERT INTO `Entity` VALUES(4, 'anonymous4', 1);
INSERT INTO `Entity` VALUES(5, 'anonymous5', 1);
INSERT INTO `Entity` VALUES(6, 'anonymous6', 1);
INSERT INTO `Entity` VALUES(7, 'anonymous7', 1);
INSERT INTO `Entity` VALUES(8, 'anonymous8', 1);
INSERT INTO `Entity` VALUES(9, 'anonymous9', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Testimonial`
--

CREATE TABLE `Testimonial` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `proof` blob NOT NULL,
  `entity_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Testimonial`
--


-- --------------------------------------------------------

--
-- Table structure for table `Transaction`
--

CREATE TABLE `Transaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `from` bigint(20) NOT NULL,
  `to` bigint(20) NOT NULL,
  `amount` float NOT NULL,
  `testimonial_id` bigint(20) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `Transaction`
--

INSERT INTO `Transaction` VALUES(1, 1, 2, 23000, 1, '2012-12-01 17:24:56');
INSERT INTO `Transaction` VALUES(2, 1, 3, 23000, 1, '2012-12-01 17:59:10');
INSERT INTO `Transaction` VALUES(3, 2, 4, 10000, 1, '2012-12-01 18:01:58');
INSERT INTO `Transaction` VALUES(4, 3, 5, 10000, 1, '2012-12-01 18:02:14');
INSERT INTO `Transaction` VALUES(5, 2, 6, 5000, 1, '2012-12-01 18:15:08');
